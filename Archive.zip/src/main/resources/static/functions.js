function addToFavorites() {
	var favorites = document.getElementsByClass("favorites");
	return favorites; 
}