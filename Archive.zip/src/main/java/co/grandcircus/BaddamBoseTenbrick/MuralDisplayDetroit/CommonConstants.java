package co.grandcircus.BaddamBoseTenbrick.MuralDisplayDetroit;

public class CommonConstants {

	public static String ACCESS_KEY_ID = "AKIAI3JCWTBGJIBATBMA";
			
	public static String ACCESS_SEC_KEY = "9FY2kVz1AjIvlBiU7jZlD/OXWEAcFbAHECWh+FX1";
	
	public static String BUCKET_NAME = "muralbucket";
}
