# Street Art Detroit

This WebApp will display a collection of public art in the city of Detroit. You can see the location of all the murals overlayed on a map, or a gallery of images sorted by neighborhood.

Users can log-in to select their favorite art peices and recieve recommendations based on a collaborative filtering algorithm.
